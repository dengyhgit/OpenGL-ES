//
//  ViewController.swift
//  OpenGL02
//
//  Created by deng on 16/7/7.
//  Copyright © 2016年 dengyonghao. All rights reserved.
//

import GLKit

struct SceneVertex {
    var positionCoords : GLKVector3
}

var vertices = [
    SceneVertex(positionCoords: GLKVector3Make(-0.5, -0.5, 0.0)),
    SceneVertex(positionCoords: GLKVector3Make(0.5, -0.5, 0.0)),
    SceneVertex(positionCoords: GLKVector3Make(0.5, 0.5, 0.0)),
    SceneVertex(positionCoords: GLKVector3Make(-0.5, 0.5, 0.0))
]

class ViewController: GLKViewController {
    
    var vertextBuffer = AGLKVertexAttribArrayBuffer()
    var vertextBufferId = GLuint()
    var baseEffect = GLKBaseEffect.init()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let view = self.view as! GLKView
        view.context = AGLKContext.init(API: EAGLRenderingAPI.OpenGLES3)
        AGLKContext.setCurrentContext(view.context)
        
        //使用恒定不变的颜色
        baseEffect.useConstantColor = GLboolean(UInt8(GL_TRUE))
        baseEffect.constantColor = GLKVector4Make(1, 0, 1, 1)
        
        self.vertextBuffer.initWithAttribStride(GLsizei(sizeofValue(vertices[0])), numberOfVertices: GLsizei(vertices.count), dataPtr: vertices, usage:GLenum(GL_STATIC_DRAW))
    }
    
    override func glkView(view: GLKView, drawInRect rect: CGRect) {
        baseEffect.prepareToDraw()
        getCurrentContext().clear(GLenum(GL_COLOR_BUFFER_BIT))
        
        
        self.vertextBuffer.prepareToDrawWithAttrib(AGLKVertexAttrib.AGLKVertexAttribPosition.rawValue, numberOfCoordinates: 3, attribOffset:0, shouldEnable: true)
        
        self.vertextBuffer.drawArrayWithMode(GLenum(GL_TRIANGLE_FAN), startVertexIndex: 0, numberOfVertices: GLsizei(vertices.count))
        
    }
    
    func getCurrentContext() -> AGLKContext {
        let view = self.view as! GLKView
        return view.context as! AGLKContext
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}

