//
//  ViewController.swift
//  OpenGL04
//
//  Created by deng on 16/7/11.
//  Copyright © 2016年 dengyonghao. All rights reserved.
//

import UIKit
import GLKit

extension GLKEffectPropertyTexture {
    func aglkSetParameter(parameterID: GLenum, value: GLint) {
        glBindTexture(self.target.rawValue, self.name);
        
        glTexParameteri(
            self.target.rawValue,
            parameterID,
            value);
    }
}

struct SceneVertex {
    var positionCoords : GLKVector3
    var textureCoords: GLKVector2
}

var vertices = [
    SceneVertex(positionCoords: GLKVector3Make(-0.5, -0.5, 0.0),
        textureCoords:GLKVector2Make(0.0, 0.0)),
    SceneVertex(positionCoords: GLKVector3Make(0.5, -0.5, 0.0),
        textureCoords:GLKVector2Make(1.0, 0.0)),
    SceneVertex(positionCoords: GLKVector3Make(0.5, 0.5, 0.0),
        textureCoords:GLKVector2Make(1.0, 1.0)),
    SceneVertex(positionCoords: GLKVector3Make(-0.5, 0.5, 0.0),
        textureCoords:GLKVector2Make(0.0, 1.0))
]

var DefaultVertices = [
    SceneVertex(positionCoords: GLKVector3Make(-0.5, -0.5, 0.0),
        textureCoords:GLKVector2Make(0.0, 0.0)),
    SceneVertex(positionCoords: GLKVector3Make(0.5, -0.5, 0.0),
        textureCoords:GLKVector2Make(1.0, 0.0)),
    SceneVertex(positionCoords: GLKVector3Make(0.5, 0.5, 0.0),
        textureCoords:GLKVector2Make(1.0, 1.0)),
    SceneVertex(positionCoords: GLKVector3Make(-0.5, 0.5, 0.0),
        textureCoords:GLKVector2Make(0.0, 1.0))
]

var movementVectors: [GLKVector3] = [
    GLKVector3Make(-0.01, -0.01, 0.0),
    GLKVector3Make(0.01, -0.01, 0.0),
    GLKVector3Make(0.01, 0.01, 0.0),
    GLKVector3Make(-0.01, 0.01, 0.0)
]


class ViewController: GLKViewController {
    
    var vertextBuffer = AGLKVertexAttribArrayBuffer()
    var vertextBufferId = GLuint()
    var baseEffect = GLKBaseEffect.init()
    
    var shouldUseLinearFilter = true
    var shouldAnimate = true
    
    func update() {
        //添加滤镜
        updateTextureParameters()
        //添加动画
        updateAnimatedVertexPositions()
        //重新加载缓存数据
        self.vertextBuffer.reinitWithAttribStride(GLsizei(sizeofValue(vertices[0])), numberOfVertices: GLsizei(vertices.count), dataPtr: vertices)
    }
    
    func updateAnimatedVertexPositions() {
        if shouldAnimate {
            for index in 0...3 {
                vertices[index].positionCoords = GLKVector3Make(vertices[index].positionCoords.x + movementVectors[index][0], vertices[index].positionCoords.y, vertices[index].positionCoords.z)
                
                if vertices[index].positionCoords.x >= 1.0 ||
                    vertices[index].positionCoords.x <= -1.0
                {
                    movementVectors[index] = GLKVector3Make(-movementVectors[index][0], movementVectors[index][1], movementVectors[index][2]);
                }
                
                if vertices[index].positionCoords.y >= 1.0 ||
                    vertices[index].positionCoords.y <= -1.0
                {
                    movementVectors[index] = GLKVector3Make(movementVectors[index][0], -movementVectors[index][1], movementVectors[index][2]);
                }
                
                if vertices[index].positionCoords.z >= 1.0 ||
                    vertices[index].positionCoords.z <= -1.0
                {
                    movementVectors[index] = GLKVector3Make(movementVectors[index][0], movementVectors[index][1], -movementVectors[index][2]);
                }
            }
        } else {
            vertices = DefaultVertices
        }
    }
    
    func updateTextureParameters() {
        self.baseEffect.texture2d0.aglkSetParameter(GLenum(GL_TEXTURE_MAG_FILTER), value: self.shouldUseLinearFilter ? GL_LINEAR : GL_NEAREST)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.preferredFramesPerSecond = 1;
        
        let view = self.view as! GLKView
        view.context = AGLKContext.init(API: EAGLRenderingAPI.OpenGLES3)
        AGLKContext.setCurrentContext(view.context)
        
        
        self.vertextBuffer.initWithAttribStride(
            GLsizei(sizeofValue(vertices[0])),
            numberOfVertices: GLsizei(vertices.count),
            dataPtr: vertices,
            usage:GLenum(GL_STATIC_DRAW)
        )
        
        // 设置 纹理
        let imageRef = UIImage(named: "80.png")?.CGImage
        var textureInfo: GLKTextureInfo!
        
        do {
            textureInfo = try GLKTextureLoader.textureWithCGImage(imageRef!, options: nil)
        } catch {
            
        }
        
        self.baseEffect.texture2d0.name = textureInfo.name;
        self.baseEffect.texture2d0.target = GLKTextureTarget(rawValue: textureInfo.target)!
        
    }
    
    override func glkView(view: GLKView, drawInRect rect: CGRect) {
        baseEffect.prepareToDraw()
        getCurrentContext().clear(GLenum(GL_COLOR_BUFFER_BIT))
        
        self.vertextBuffer.prepareToDrawWithAttrib(
            AGLKVertexAttrib.AGLKVertexAttribPosition.rawValue,
            numberOfCoordinates: 3,
            attribOffset:0,
            shouldEnable: true
        )
        
        self.vertextBuffer.prepareToDrawWithAttrib(
            AGLKVertexAttrib.AGLKVertexAttribTexCoord0.rawValue,
            numberOfCoordinates: 2,
            //设置偏移量
            attribOffset:sizeof(GLfloat) * 4,    //offset
            shouldEnable: true
        )
        
        self.vertextBuffer.drawArrayWithMode(
            GLenum(GL_TRIANGLE_FAN),
            startVertexIndex: 0,
            numberOfVertices:
            GLsizei(vertices.count)
        )
        
    }
    
    func getCurrentContext() -> AGLKContext {
        let view = self.view as! GLKView
        return view.context as! AGLKContext
    }
    
    @IBAction func takeShouldAnimateFrom(sender: AnyObject) {
        self.shouldAnimate = sender.on
    }
    
    @IBAction func takeShouldUseLinearFilterFrom(sender: AnyObject) {
        self.shouldUseLinearFilter = sender.on
    }

}

