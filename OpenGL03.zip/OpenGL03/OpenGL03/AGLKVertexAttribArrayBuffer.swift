//
//  AGLKVertexAttribArrayBuffer.swift
//  OpenGL02
//
//  Created by deng on 16/7/7.
//  Copyright © 2016年 dengyonghao. All rights reserved.
//

import GLKit

enum AGLKVertexAttrib: GLuint {
    case AGLKVertexAttribPosition = 0
    case AGLKVertexAttribNormal = 1
    case AGLKVertexAttribColor = 2
    case AGLKVertexAttribTexCoord0 = 3
    case AGLKVertexAttribTexCoord1 = 4
}

//封装顶点数组缓存
class AGLKVertexAttribArrayBuffer: NSObject {
    //步幅，表示每个顶点需要多少个字节
    var stride = GLsizei()
    //缓存大小
    var bufferSizeBytes = GLsizeiptr()
    //缓存唯一标识
    var bufferId = GLuint()
    
    
    
    /**
     创建顶点数组缓存
     
     - parameter stride:           步幅
     - parameter numberOfVertices: Vertices大小
     - parameter bytes:            Vertices内存地址
     - parameter usage:            是否缓存在GPU
     
     */
    func initWithAttribStride(stride: GLsizei, numberOfVertices: GLsizei, dataPtr: UnsafePointer<Void>, usage: GLenum) {
        self.stride = stride
        bufferSizeBytes = Int(stride) * Int(numberOfVertices);
        
        glGenBuffers(1, &bufferId)
        glBindBuffer(GLenum(GL_ARRAY_BUFFER), self.bufferId)
        glBufferData(
            GLenum(GL_ARRAY_BUFFER),
            bufferSizeBytes,
            dataPtr,
            usage
        )
    }
    
    //重新加载缓存数据
    func reinitWithAttribStride(stride: GLsizei, numberOfVertices:GLsizei, dataPtr:  UnsafePointer<Void>) {
        self.stride = stride;
        bufferSizeBytes = Int(stride) * Int(numberOfVertices);
        
        glBindBuffer(GLenum(GL_ARRAY_BUFFER),
                     self.bufferId);
        glBufferData(
            GLenum(GL_ARRAY_BUFFER),
            bufferSizeBytes,
            dataPtr,
            GLenum(GL_DYNAMIC_DRAW)
        );
    }
    
    /**
     Description
     
     - parameter index:               VertexAttrib
     - parameter numberOfCoordinates: 坐标轴数
     - parameter attribOffset:        从开始的每个顶点偏移
     - parameter shouldEnable:        启用（Enable）或者禁用（Disable）
     */
    func prepareToDrawWithAttrib(vertexAttrib: GLuint, numberOfCoordinates: GLint, attribOffset: GLsizeiptr, shouldEnable: Bool) {
    
        glBindBuffer(GLenum(GL_ARRAY_BUFFER), self.bufferId);
        
        if(shouldEnable)
        {
            glEnableVertexAttribArray(vertexAttrib)
        }
        
        glVertexAttribPointer(         
            vertexAttrib,
            numberOfCoordinates,                // 坐标轴数
            GLenum(GL_FLOAT),                   // 数据类型
            GLboolean(UInt8(GL_FALSE)),
            self.stride,
            nil + attribOffset);                // 从开始的每个顶点偏移
    }
    
    //绘制图片
    func drawArrayWithMode(mode:GLenum, startVertexIndex: GLint, numberOfVertices: GLsizei) {
        glDrawArrays(mode, startVertexIndex, numberOfVertices);
    }
    
    //删除缓存
    deinit {
        if 0 != bufferId {
            glDeleteBuffers (1, &bufferId);
            bufferId = 0;
        }
    }
    
}
