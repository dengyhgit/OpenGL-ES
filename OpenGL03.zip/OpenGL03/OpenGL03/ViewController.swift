//
//  ViewController.swift
//  OpenGL03
//
//  Created by deng on 16/7/8.
//  Copyright © 2016年 dengyonghao. All rights reserved.
//

import UIKit
import GLKit

struct SceneVertex {
    var positionCoords : GLKVector3
    var textureCoords: GLKVector2
}

var vertices = [
    SceneVertex(positionCoords: GLKVector3Make(-0.5, -0.5, 0.0),
                textureCoords:GLKVector2Make(0.0, 0.0)),
    SceneVertex(positionCoords: GLKVector3Make(0.5, -0.5, 0.0),
                textureCoords:GLKVector2Make(1.0, 0.0)),
    SceneVertex(positionCoords: GLKVector3Make(0.5, 0.5, 0.0),
                textureCoords:GLKVector2Make(1.0, 1.0)),
    SceneVertex(positionCoords: GLKVector3Make(-0.5, 0.5, 0.0),
                textureCoords:GLKVector2Make(0.0, 1.0))
]

class ViewController: GLKViewController {
    
    var vertextBuffer = AGLKVertexAttribArrayBuffer()
    var vertextBufferId = GLuint()
    var baseEffect = GLKBaseEffect.init()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let view = self.view as! GLKView
        view.context = AGLKContext.init(API: EAGLRenderingAPI.OpenGLES3)
        AGLKContext.setCurrentContext(view.context)
        
        self.vertextBuffer.initWithAttribStride(
            GLsizei(sizeofValue(vertices[0])),
            numberOfVertices: GLsizei(vertices.count),
            dataPtr: vertices,
            usage:GLenum(GL_STATIC_DRAW)
        )
        
        // 设置 纹理
        let imageRef = UIImage(named: "80.png")?.CGImage
        var textureInfo: GLKTextureInfo!
        
        do {
            textureInfo = try GLKTextureLoader.textureWithCGImage(imageRef!, options: nil)
        } catch {

        }
        
        self.baseEffect.texture2d0.name = textureInfo.name;
        self.baseEffect.texture2d0.target = GLKTextureTarget(rawValue: textureInfo.target)!
        
    }
    
    override func glkView(view: GLKView, drawInRect rect: CGRect) {
        baseEffect.prepareToDraw()
        getCurrentContext().clear(GLenum(GL_COLOR_BUFFER_BIT))
        
        self.vertextBuffer.prepareToDrawWithAttrib(
            AGLKVertexAttrib.AGLKVertexAttribPosition.rawValue,
            numberOfCoordinates: 3,
            attribOffset:0,
            shouldEnable: true
        )
        
        self.vertextBuffer.prepareToDrawWithAttrib(
            AGLKVertexAttrib.AGLKVertexAttribTexCoord0.rawValue,
            numberOfCoordinates: 2,
//            GLfloat // <-- structure start
//            GLfloat // <-- position
//            GLfloat
//            GLfloat
//            GLfloat // <-- texture
//            GLfloat
//            ptr = sizeof(GLfloat) * 4
            //设置偏移量
            attribOffset:sizeof(GLfloat) * 4,    //offset
            shouldEnable: true
        )
        
        self.vertextBuffer.drawArrayWithMode(
            GLenum(GL_TRIANGLE_FAN),
            startVertexIndex: 0,
            numberOfVertices:
            GLsizei(vertices.count)
        )
        
    }
    
    func getCurrentContext() -> AGLKContext {
        let view = self.view as! GLKView
        return view.context as! AGLKContext
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}

