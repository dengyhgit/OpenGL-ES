//
//  ViewController.swift
//  OpenGL01
//
//  Created by deng on 16/6/29.
//  Copyright © 2016年 dengyonghao. All rights reserved.
//

import GLKit

extension Array {
    func size () -> Int {
        if self.count > 0 {
            return self.count * sizeofValue(self[0])
        }
        return 0;
    }
}

struct SceneVertex {
    var positionCoords : GLKVector3
}

var vertices = [
    SceneVertex(positionCoords: GLKVector3Make(-0.5, -0.5, 0.0)),
    SceneVertex(positionCoords: GLKVector3Make(0.5, -0.5, 0.0)),
    SceneVertex(positionCoords: GLKVector3Make(0.5, 0.5, 0.0)),
    SceneVertex(positionCoords: GLKVector3Make(-0.5, 0.5, 0.0))
]

class ViewController: GLKViewController {
    
    var vertextBufferId: GLuint = GLuint()
    var baseEffect = GLKBaseEffect.init()

    override func viewDidLoad() {
        super.viewDidLoad()
        let view = self.view as! GLKView
        view.context = EAGLContext.init(API: EAGLRenderingAPI.OpenGLES3)
        EAGLContext.setCurrentContext(view.context)
        
        //使用恒定不变的颜色
        baseEffect.useConstantColor = GLboolean(UInt8(GL_TRUE))
        baseEffect.constantColor = GLKVector4Make(1, 0, 1, 1)
        
        /**
            &0：生成缓存标识符的数量
            &1：生成标识符的内存位置
         */
        glGenBuffers(1, &vertextBufferId)
        
        //绑定缓存
        glBindBuffer(GLenum(GL_ARRAY_BUFFER), vertextBufferId)
        
        //缓存数据
        glBufferData(GLenum(GL_ARRAY_BUFFER), vertices.size(), vertices, GLenum(GL_STATIC_DRAW))
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    override func glkView(view: GLKView, drawInRect rect: CGRect) {
        baseEffect.prepareToDraw()
        glClear(GLenum(GL_COLOR_BUFFER_BIT))
        glEnableVertexAttribArray(0)
        glVertexAttribPointer(
            0,
            3,                              //坐标轴数
            GLenum(GL_FLOAT),
            GLboolean(UInt8(GL_FALSE)),
            GLsizei(sizeof(SceneVertex)),
            nil
        )
        glDrawArrays(
            GLenum(GL_TRIANGLE_FAN), //根据实际来设置样式
            0,                       //从buffers中的第一个vertice开始
            GLsizei(vertices.count)
        )
    }
}

